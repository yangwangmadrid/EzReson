#!/bin/bash

export EZREON_DIR="Path of EzReson_v3.0_release"

/opt/local/bin/python3 -u ${EZREON_DIR}/ezreson.py $*
