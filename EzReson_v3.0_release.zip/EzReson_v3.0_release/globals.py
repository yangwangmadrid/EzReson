# Definition of global variables
#
# Created on Oct 2, 2021
# Written by Yang Wang (yangwang@yzu.edu.cn)
#
# 

def initialize(): 
    global basename
    basename = ''
    global ifWrite_Overlap 
    ifWrite_Overlap = False
    global ifWrite_Hamilt
    ifWrite_Hamilt = False

# enddef initialize()
